package Aasstiation;
public class Passport {
    private String PassportNo;
    private String expireDate;
    private int page;
    public Passport(){

    }
    public Passport(String PassportNo,String expireDate,int page){
        this.PassportNo=PassportNo;
        this.expireDate=expireDate;
        this.page=page;
    }
    void setPassportNo(String PassportNo){
        this.PassportNo=PassportNo;
    }
    void setExpireDate(String expireDate){
        this.expireDate=expireDate;
    }
    void setpage(int page){
        this.page=page;
    }
    String getPassportNo(){
        return this.PassportNo;
    }
    String getExpireDate(){
        return this.expireDate;
    }
    int getpage(){
        return this.page;
    }
    void showPassportInfo(){
        System.out.println("Passportno is :"+this.PassportNo);
        System.out.println("Expire Date:"+this.expireDate);
        System.out.println("Page No:"+this.page);
    }


}
