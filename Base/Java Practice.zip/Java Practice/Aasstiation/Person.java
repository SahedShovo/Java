package Aasstiation;
public class Person {
    private String name;
    private int age;
    private Passport pp;
    public Person(){}
    public Person(String name,int age,Passport pp){
        this.name=name;
        this.age=age;
        this.pp=pp;

    }
    void setName(String name){
        this.name=name;
    }
    void setAge(int age){
        this.age=age;
    }
    void setPassport(Passport pp){
        this.pp=pp;
    }
    String getName(){
        return this.name;
    }
    int getAge(){
        return this.age;
    }
    Passport getPassport(){
        return this.pp;
    }
    void showAllInfo(){
        System.out.println("Peerson Name:"+this.name);
        System.out.println("Person Age:"+this.age);
        pp.showPassportInfo();
    }

}
