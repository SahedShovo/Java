package Aasstiation;
public class Start {
    public static void main(String[]args){
        Passport ps1=new Passport();
        ps1.setExpireDate("10.10.2015");
        ps1.setPassportNo("20");
        ps1.setpage(50);
        ps1.showPassportInfo();
        System.out.println();

        Passport ps2=new Passport("21","25.11.2015",100);
        ps2.showPassportInfo();
        System.out.println();

        Person p1=new Person();
        p1.setName("Sahed Ahmed");
        p1.setAge(25);
        p1.setPassport(ps1);
        p1.showAllInfo();
        System.out.println();

        Person p2=new Person();
        p2.setAge(18);
        p2.setName("Nahid Ahmed");
        p2.setPassport(ps2);
        p2.showAllInfo();


    }
    
}
