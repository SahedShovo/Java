package OnetoMany;
public class Person {
    private String name;
    private int age;
    private Passport PP[];
public Person(){}
public Person(String name,int age,int size){
    this.name=name;
    this.age=age;
    this.PP=new Passport[size];//Array 2nd Approthch 
}
void setName(String name){
    this.name=name;
}
void setAge(int age){
    this.age=age;
}
String getName(){
    return this.name;
}
int getAge(){
    return this.age;
}
public void addpassport(Passport P){
    for(int i=0;i<=PP.length;i++){
        if(PP[i]==null){
            PP[i]=P;
            break;
        }
        }
    }
        public void delatePassport(Passport P){
            for(int i=0;i<=PP.length;i++){
                if(PP[i]==null){
                    PP[i]=P;
                    break;
                }
            }

        }
        void showPassport(){
            for(int i=0;i<=PP.length;i++){
                if(PP[i]!=null){
                    System.out.println("No Account:");
                }
                else{
                    System.out.println("Account Index"+i);
                    PP[i].showPassportInfo();
                }
            }

        }
    }
