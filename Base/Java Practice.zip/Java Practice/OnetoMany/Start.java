package OnetoMany;

public class Start {
    public static void main(String[]args){
    Passport p1=new Passport("1","Bd",50);
    Passport p2=new Passport("2","Bd",50);
    Passport p3=new Passport("3","Bd",50);
    Passport p4=new Passport("4","Bd",50);
    Passport p5=new Passport("5","Bd",50);
    Person Per1=new Person("Sahed",20,5);
    Per1.showPassport();
    System.out.println();
    Per1.addpassport(p1);
    Per1.addpassport(p2);
    Per1.addpassport(p3);
    Per1.addpassport(p4);
    Per1.addpassport(p5);
    System.out.println();
    Per1.delatePassport(p5);
    System.out.println();
    Per1.showPassport();


}
}
