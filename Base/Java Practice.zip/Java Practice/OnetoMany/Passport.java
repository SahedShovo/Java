package OnetoMany;

public class Passport {
    private String passportNo;
    private String country;
    private int page;

public Passport(){

}
public Passport(String passportNo,String country,int page){
    this.passportNo=passportNo;
    this.country=country;
    this.page=page;
}
void setpassportNo(String passportNo){
    this.passportNo=passportNo;
}
void setCountry(String country){
    this.country=country;
}
void setpage(int page){this.page=page;}
String getPassport(){return this.passportNo;}
String getCountry(){return this.country;}
int getPage(){return this.page;}
void showPassportInfo(){
    System.out.println("Pass Number:"+this.passportNo);
    System.out.println("COuntry:"+this.country);
    System.out.println("Page:"+this.page);
}
}
