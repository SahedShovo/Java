package Many;
public class Start {
        public static void main(String[] args) {
            //  five Passport objects
            Passport p1 = new Passport("1", "Bangkadesh", 30);
            Passport p2 = new Passport("2", "UK", 25);
            Passport p3 = new Passport("3", "Canada", 20);
            Passport p4 = new Passport("4", "Australia", 35);
            Passport p5 = new Passport("5", "Germany", 28);
     
            //  Person object
            Person per1 = new Person("Sahed", 21, 5);
     
            // Demonstrating methods
            per1.addPassport(p1);
            System.out.println();
            per1.addPassport(p2);
            per1.addPassport(p3);
            per1.addPassport(p4);
            per1.addPassport(p5);
            System.out.println();
            per1.showPassports();
            System.out.println();
     
            System.out.println("\nDeleting passport 4 Australia");
            per1.deletePassport(p4);
            System.out.println();
            per1.showPassports();
        }
    }
