package Many;
public class Passport {
        private String passportNo;
        private String country;
        private int pages;
     
        public Passport() {}
     
        public Passport(String passportNo, String country, int pages) {
            this.passportNo = passportNo;
            this.country = country;
            this.pages = pages;
        }
     
        public void setPassportNo(String passportNo) {
            this.passportNo = passportNo;
        }
     
        public void setCountry(String country) {
            this.country = country;
        }
     
        public void setPages(int pages) {
            this.pages = pages;
        }
     
        public String getPassportNo() {
            return this.passportNo;
        }
     
        public String getCountry() {
            return this.country;
        }
     
        public int getPages() {
            return this.pages;
        }
     
        public void showPassportInfo() {
            System.out.println("Passport Number: " + passportNo);
            System.out.println("Country: " + country);
            System.out.println("Number of Pages: " + pages);
            System.out.println();
        }
    }
     
