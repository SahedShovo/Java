package Many;
public class Person {
        private String name;
        private int age;
        private Passport[] pp;

     
        public Person() {}
     
        public Person(String name, int age, int size) {
            this.name = name;
            this.age = age;
            this.pp = new Passport[size];//2nd Approtch
        }
     
        public void setName(String name) {
            this.name = name;
        }
     
        public void setAge(int age) {
            this.age = age;
        }
     
        public String getName() {
            return name;
        }
     
        public int getAge() {
            return age;
        }
     
        public void addPassport(Passport p) {
            for (int i = 0; i < pp.length; i++) {
                if (pp[i] == null) {
                    pp[i] = p;
                    break;
                }
            }
        }
     
        public void deletePassport(Passport p) {
            for (int i = 0; i < pp.length; i++) {
                if (pp[i] == p) {
                    pp[i] = null;
                    break;
                }
            }
        }
     
        public void showPassports() {
            System.out.println("Passports of " + name + ":");
            for (int i=0;i<pp.length;i++) {
                if (pp[i] != null) {
                    pp[i].showPassportInfo();
                }
            }
        }
    }
     
    