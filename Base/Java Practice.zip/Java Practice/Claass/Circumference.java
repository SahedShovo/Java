
public class Circumference {
    private double radious;

    public Circumference(){
        System.out.println("Defaoult Constractor");
    }
    Circumference(double radious){
        this.radious=radious;
    }
    public void setradious(double radious){
        this.radious=radious;
    }
    public double getredious(){
        return radious;
    }
    public double getArea(){
        return radious*radious;
    }
    public double getCircumference(){
        return 2*Math.PI*radious;
    }
    public static void main(String[]args){
        Circumference obj1=new Circumference(10);
        System.out.println("Area is :"+obj1.getArea());
        System.out.println("Circumference is :"+obj1.getCircumference());
        obj1.setradious(40);
        System.out.println("Upgradet Area is :"+obj1.getArea());
        System.out.println("Upgrated Circumference is :"+obj1.getCircumference());
        
    }
}
