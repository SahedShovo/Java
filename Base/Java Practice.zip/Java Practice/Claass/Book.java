public class Book {
    private String Title;
    private String Another;
    private String ISBN;
    private String Methods;

    public Book(){
        System.out.println("Defaoult Constractor");
    }
    Book(String Title,String Another,String ISBN,String Methods){
        this.Another=Another;
        this.Title=Title;
        this.ISBN=ISBN;
        this.Methods=Methods;
    }
    public void SetBook(String Title,String Another,String ISBN,String Methods){
        this.Title=Title;
        this.Another=Another;
        this.ISBN=ISBN;
        this.Methods=Methods;
    }
    public String getTitle(){
        return Title;
    }
    public String getAnother(){
        return Another;
    }
    public String getISBSN(){
        return ISBN;
    }
    public String getMethods(){
        return Methods;
    }

    
}
