
public class Dog {
    private String name;
    private String Breed;

public Dog(String name,String Breed){
    this.name=name;
    this.Breed=Breed;
}
public String getname(){
    return name;
}
public String getBreed(){
    return Breed;
}
public void setBreed(String Breed){
this.Breed=Breed;
}
void Displayinformation(){
    System.out.println(name+" is a "+Breed+" . ");
}
}