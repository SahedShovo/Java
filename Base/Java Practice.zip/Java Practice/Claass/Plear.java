
 public class Plear {
	 
	 private int  age;
	 private String  name;
	 private String  cuntry;
	 
	 public Plear (){
		 System.out.println("Deafoult value");
	 }
	  Plear (int age,String name,String cuntry){
		 this. age = age ;
		 this. name = name;
		 this. cuntry = cuntry;
		 
	//value assigne	 
	 }
	 public void  setplear (int age,String name,String cuntry){
		 this. age = age ;
		 this. name = name;
		 this. cuntry = cuntry;
	 }
	 public int getage(){
		 return this. age;
		 
	 }
     public String getname(){
		 return this. name;
		 
	 }
     public String getcuntry(){
		 return  this.cuntry;
		 
	 }
    public void showditals(){
		System.out.println("Age="+getage());
		System.out.println("Name="+getname());
	    System.out.println("Cuntry="+getcuntry());
	}
    public static void main(String[]args ){
	    Plear obj1  = new Plear(20,"fadu","BD");
    obj1. showditals();
  
     Plear obj2  = new Plear(27,"adu","BD");
    obj2. showditals();
	
	Plear obj3  = new Plear(25,"gedu","BD");
    obj3. showditals();
 
    
  
	
  }
  
 }

