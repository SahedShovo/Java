
public class Rectangle {
    private double Weight;
    private double Long;

    public Rectangle(){
        System.out.println("Defaoult Cons!");
    }
    Rectangle(double Weight,double Long){
        System.out.println("Pera Cons!");
        this.Weight=Weight;
        this.Long=Long;
    }
    public void setWeight(double Weight,double Long ){
        this.Weight=Weight;
        this.Long=Long;
    }
    public double getWeight(){
        return Weight;
    }
    public double getLong(){
        return Long;
    }
    public double getArea(){
        return Weight*Long;
    }
    public double getperamiter(){
        return 2*Long+Weight;
    }
    public static void main(String[] args) {
        Rectangle obj1=new Rectangle(7,12);
            System.out.println("The Ara is :"+obj1.getArea());
            System.out.println("The peramiter is :"+obj1.getperamiter());

            obj1.setWeight(10,20);
            System.out.println("The Update Value of Area :"+obj1.getArea());
            System.out.println("The Updated Vlue of Peramiter is :"+obj1.getperamiter());


    }
}

