
public class Start {
    public static void main(String[]args){
       // Main.java
      Dog dog1 = new Dog("Buddy", "Golden Retriever");
      Dog dog2 = new Dog("Charlie", "Bulldog");
      dog1.Displayinformation();
      dog2.Displayinformation();
  
      System.out.println("\nSet the new Breed of dog1 and new name of dog2:");
      dog1.setBreed("Labrador Retriever");
      dog2.setBreed("Daisy");
  
      System.out.println(dog1.getname() + " is now a " + dog1.getBreed() + ".");
      System.out.println(dog2.getname() + " is now a " + dog2.getBreed() + ".");
    }
  }
  
