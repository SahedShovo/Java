
public class Student {
    private String name;
    private int grade;
    private String courses;

    // Constructor
    public Student(String name, int grade,String courses) {
        this.name = name;
        this.grade = grade;
        this.courses = courses;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;
    }

    public String getCourses() {
        return courses;
    }

    // Method to add a course
    public void addCourse(String course) {
        this.courses=course;
        System.out.println(course + " added to " + name + "'s courses.");
    }

    // Method to remove a course
    public void removeCourse(String course) {
        if (courses.contains(course)) {
            System.out.println(course + " removed from " + name + "'s courses.");
        } else {
            System.out.println(name + " is not enrolled in " + course + ".");
        }
    }

    public static void main(String[] args) {
        // Example usage
        Student student1 = new Student("jhon",10,"Math");
        System.out.println(student1.getName() + "'s courses: " + student1.getCourses());

        // Adding courses
        student1.addCourse("Science");

        // Displaying current courses
        System.out.println(student1.getName() + "'s courses: " + student1.getCourses());
        // Removing a course
        student1.removeCourse("Science");

        // Displaying updated courses
        System.out.println(student1.getName() + "'s courses: " + student1.getCourses());
    }
}

