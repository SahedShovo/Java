//step 6
import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		FrameSample obj1 = new FrameSample();
		//SecondFrame obj1 = new SecondFrame();
		obj1.setVisible(true);
	}
}