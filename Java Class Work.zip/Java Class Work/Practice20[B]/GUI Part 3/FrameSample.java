//step 0
import java.lang.*;
import javax.swing.*;
import java.awt.*; //this package is used for font & coloring
import java.awt.event.*; //used for interface
//step 1
public class FrameSample extends JFrame implements MouseListener, ActionListener
{
	//step 2
	private JPanel panel;
	private JLabel label1, label2, label3, label4, label5, label6, label7;
	private JTextField txt1;
	private JPasswordField pf;
	private JButton bt1, bt2, bt3, bt4;
	private JRadioButton rb1, rb2;
	private ButtonGroup bg;
	private JCheckBox cb1, cb2;
	private JComboBox jb;
	private ImageIcon img;
	private Color color1, color2, color3;
	private Font f1;
	
	//step 4
	public FrameSample() 
	{
		//step 4 (a)
		super("My First GUI");
		//super.setSize(800,400); //(width,height)
		super.setBounds(600,200, 800,500); //(x,y,width, height)
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(0, 0, 186); //(R,G,B)
		
		//step 4 (b)
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(color1);
		
		//step 4 (d)
		label1 = new JLabel("Hello OOP1[B]");
		label1.setBounds(130,20,150,50);
		panel.add(label1);
		f1 = new Font("Cambria",Font.BOLD,20); //(name, style, size)
		label1.setFont(f1);
		color2 = new Color(255, 0, 0); //(R,G,B)
		label1.setForeground(color2);
		color3 = new Color(0, 0, 0); //(R,G,B)
		label1.setBackground(color3);
		label1.setOpaque(true); //used for color overlapping
		label1.addMouseListener(this);
		
		
		label2 = new JLabel("Your Name");
		label2.setBounds(100,70,80,60);
		panel.add(label2);
		
		txt1 = new JTextField();
		txt1.setBounds(190,90,150,20);
		panel.add(txt1);
		txt1.setBackground(Color.RED);
		
		label3 = new JLabel("Your CGPA");
		label3.setBounds(100,100,80,60);
		panel.add(label3);
		
		pf = new JPasswordField();
		pf.setBounds(190,120,150,20);
		panel.add(pf);
		pf.setBackground(Color.RED);
		pf.setEchoChar('$');
		
		label4 = new JLabel("Your Gender");
		label4.setBounds(100,130,80,60);
		panel.add(label4);
		
		rb1 = new JRadioButton("Male");
		rb1.setBounds(200,145,70,25);
		panel.add(rb1);
		rb1.setForeground(Color.RED);
		
		rb2 = new JRadioButton("Female");
		rb2.setBounds(280,145,80,25);
		panel.add(rb2);
		
		bg = new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		
		label5 = new JLabel("Topic");
		label5.setBounds(100,160,80,60);
		panel.add(label5);
		
		cb1 = new JCheckBox("Inheritance");
		cb1.setBounds(200,175,150,25);
		panel.add(cb1);
		
		cb2 = new JCheckBox("GUI");
		cb2.setBounds(200,205,150,25);
		panel.add(cb2);
		cb2.setBackground(Color.GREEN);
		cb2.setForeground(Color.RED);
		
		label6 = new JLabel("Section");
		label6.setBounds(100,230,80,60);
		panel.add(label6);
		
		String arr1[] = new String[] {" ", "A", "B", "C"};
		jb = new JComboBox(arr1);
		jb.setBounds(200,250,80,20);
		panel.add(jb);
		jb.setBackground(Color.black);
		jb.setForeground(Color.RED);
		
		img = new ImageIcon("SectionB.jpg");
		label7 = new JLabel(img);
		label7.setBounds(400,40,350,257);
		panel.add(label7);
		
		bt1 = new JButton("Submit");
		bt1.setBounds(290,280,100,20);
		panel.add(bt1);
		bt1.setBackground(Color.GREEN);
		bt1.setForeground(Color.RED);
		bt1.addMouseListener(this);
		
		bt2 = new JButton("Exit");
		bt2.setBounds(290,310,100,20);
		panel.add(bt2);
		bt2.setBackground(Color.GREEN);
		bt2.setForeground(Color.RED);
		bt2.addActionListener(this);
		
		bt3 = new JButton("Show");
		bt3.setBounds(290,340,100,20);
		panel.add(bt3);
		bt3.setBackground(Color.GREEN);
		bt3.setForeground(Color.RED);
		bt3.addActionListener(this);
		bt3.addMouseListener(this);
		
		bt4 = new JButton("Go");
		bt4.setBounds(290,370,100,20);
		panel.add(bt4);
		bt4.setBackground(Color.GREEN);
		bt4.setForeground(Color.RED);
		bt4.addActionListener(this);
		
		//step 4 (f)
		super.add(panel);
	}
	//MourseListener interface
	//There are 5 abstract methods in MouseListener interface
	//So, we need to override them in this class
	public void mouseClicked(MouseEvent me) 
	{ 	
		if(me.getSource() == bt1) //if bt1 (Submit) clicked
		{
			bt1.setText("Confirm");
		}
		else { }
	}
	public void mousePressed(MouseEvent me) 
	{ 
		if(me.getSource() == label1) //if label1 (Hello OOP1[B]) pressed+clicked
		{
			label1.setText("Hello JAVA[B]");
		}
		else { }
	}
	public void mouseReleased(MouseEvent me) 
	{ 
		if(me.getSource() == label1) //if label1 (Hello JAVA[B]) pressed+clicked
		{
			label1.setText("Hello OOP1[B]");
		}
		else { }
	}
	public void mouseEntered(MouseEvent me) 
	{ 
		if(me.getSource() == bt3) //if bt3 (Show) enter by the mouse
		{
			bt3.setBackground(Color.BLUE);
			bt3.setForeground(Color.WHITE);
		}
		else { }
	}
	public void mouseExited(MouseEvent me) 
	{ 
		if(me.getSource() == bt3) //if bt3 (Show) enter by the mouse
		{
			bt3.setBackground(Color.GREEN);
			bt3.setForeground(Color.RED);
		}
		else { }
	}
	
	//ActionListener interface
	//There are 1 abstract method in ActionListener interface
	//So, we need to override them in this class
	public void actionPerformed(ActionEvent me) 
	{ 
		if(me.getSource() == bt2) //if bt2 (Exit) button clicked
		{
			System.exit(0);
		}
		else if(me.getSource() == bt3) //if bt3 (Show) button clicked
		{
			JOptionPane.showMessageDialog(this,"It is showing");
		}
		else if(me.getSource() == bt4) //if bt4 (Go) button clicked
		{
			SecondFrame obj1 = new SecondFrame();
			obj1.setVisible(true);
			this.setVisible(false);
		}
	}
}