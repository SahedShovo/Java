//step 0
import java.lang.*;
import javax.swing.*;
import java.awt.*; //this package is used for font & coloring
import java.awt.event.*; //used for interface
//step 1
public class SecondFrame extends JFrame implements ActionListener
{
	//step 2
	private JPanel panel;
	private Color color1;
	private JButton bt4;
	
	public SecondFrame()
	{
		//step 4 (a)
		super("My Second GUI");
		//super.setSize(800,400); //(width,height)
		super.setBounds(600,200, 800,500); //(x,y,width, height)
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(100, 199, 186); //(R,G,B)
		
		//step 4 (b)
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(color1);
		
		bt4 = new JButton("Back");
		bt4.setBounds(290,370,100,20);
		panel.add(bt4);
		bt4.setBackground(Color.GREEN);
		bt4.setForeground(Color.RED);
		bt4.addActionListener(this);
		
		//step 4 (f)
		super.add(panel);
	}
	//ActionListener interface
	//There are 1 abstract method in ActionListener interface
	//So, we need to override them in this class
	public void actionPerformed(ActionEvent me) 
	{ 
		if(me.getSource() == bt4) //if bt4 (Back) button clicked
		{
			FrameSample obj1 = new FrameSample();
			obj1.setVisible(true);
			this.setVisible(false);
		}
	}
}