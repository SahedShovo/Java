package B; //B.java exists in B folder 
import java.lang.*;
public class B
{
	public B()
	{
		System.out.println("B showing!");
	}
}