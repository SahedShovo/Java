package A; //A.java exists in A folder 
import java.lang.*;
public class A 
{
	public A()
	{
		System.out.println("A showing!");
	}
}