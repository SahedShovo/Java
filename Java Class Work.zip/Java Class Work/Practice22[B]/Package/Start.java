import java.lang.*;
import A.*; //We want to access A.java from A folder
import B.*; //We want to access B.java from B folder
public class Start 
{
	public static void main(String[] args)
	{
		A obj1 = new A();
		B obj2 = new B();
	}
}