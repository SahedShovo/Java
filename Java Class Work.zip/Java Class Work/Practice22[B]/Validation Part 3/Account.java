import java.lang.*;
import java.io.*; // for file
import java.util.*; //for Scan the file or Read Opearion
public class Account
{
	private String user;
	private String pass;
	
	private File file;
	private FileWriter fwriter; //for insert in the file
	private Scanner sc; //will scan the text file
	
	public Account()
	{
		
	}
	public Account(String user, String pass)
	{
		this.user = user;
		this.pass = pass;
	}
	public void setUser(String user) { this.user = user; }
	public void setPass(String pass) { this.pass = pass; }
	public String getUser() { return this.user; }
	public String getPass() { return this.pass; }
	
	public void addAccount() //inset in the text file
	{
		try 
		{
			//probable error portion
			file = new File("./data.txt"); //automatically create a file named as 'data.txt'
			file.createNewFile(); 
			fwriter = new FileWriter(file,true);
			fwriter.write(getUser()+"\t");
			fwriter.write(getPass()+"\n");
			fwriter.flush();
			fwriter.close();
		}
		catch(IOException ioe) 
		{
			//solution
			ioe.printStackTrace(); //Compiler will show you where the error occurs
		}
	}

	public boolean checkAccount(String user)
	{
		boolean flag = false;
		file = new File("./data.txt");
		try 
		{
			sc = new Scanner(file);
			while(sc.hasNextLine())
			{
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[0].equals(user))
				{
					flag = true;
				}
			}
		}
		catch(IOException ioe) 
		{
			//solution
			ioe.printStackTrace(); //Compiler will show you where the error occurs
		}
		return flag;
	}
	public boolean validAccount(String user, String pass)
	{
		boolean flag = false;
		file = new File("./data.txt");
		try 
		{
			sc = new Scanner(file);
			while(sc.hasNextLine())
			{
				String line = sc.nextLine();
				String[] value = line.split("\t");
				if(value[0].equals(user) && value[1].equals(pass))
				{
					flag = true;
				}
			}
		}
		catch(IOException ioe) 
		{
			//solution
			ioe.printStackTrace(); //Compiler will show you where the error occurs
		}
		return flag;
	}
}