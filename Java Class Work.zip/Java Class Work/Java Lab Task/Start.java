import java.lang.*;
public class Start
{
	public static void main(String[] args)
	{
		Account Sahed = new Account(); 
		
		System.out.println("Using showDetails Method:");
		Sahed.showDetails(); 
		Sahed.setAccountNumber(23524932);
		Sahed.setAccountHolderName("Sahed Ahmed");
		Sahed.setBalance(1700);

		System.out.println("\nUsing get Method-");
		System.out.println("Account Number: " + Sahed.getAccountNumber());
		System.out.println("Account HolderName: " + Sahed.getAccountHolderName());
		System.out.println("Balance: " + Sahed.getBalance());
	}
}