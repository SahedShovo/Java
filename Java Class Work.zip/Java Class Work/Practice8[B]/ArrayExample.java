import java.lang.*;
public class ArrayExample 
{
	public static void main(String[] args)
	{
		//there are 4 approaches for Array
		//1st approach: size known, elements unknown
		int arr1[] = new int[5];
		int []arr2 = new int[10];
		System.out.println(arr1[0]); //0
		arr1[0] = 5;
		System.out.println(arr1[0]); //5
		arr2[9] = 9;
		System.out.println(arr2[9]); //9
		
		//2nd approach: size unknown, elements unknown
		int arr3[];
		int size = arr1[0]; //size = 5
		arr3 = new int[size];
		arr3[2] = 5;
		System.out.println(arr3[2]);
		
		//3rd approach: size unknown, elements known
		int arr4[] = new int[] {1,3,5,7,9};
		System.out.println(arr4[3]); //7
		System.out.println();
		for(int i=0; i<5; i++)
		{
			System.out.println(arr4[i]);
		}
		System.out.println();
		int []arr5 = new int[] {2,4,6,8,10};
		for(int i=0; i<arr5.length; i++)
		{
			System.out.println(arr5[i]);
		}
		System.out.println();
		//for each loop
		for(int i:arr5)
		{
			System.out.println(i);
		}
	}
}