import java.lang.*;
public class B extends A 
{
	private int z;
	public B()
	{
		System.out.println("D.C of B");
	}
	public B(int a, int b, int c)
	{
		super(a,b);
		System.out.println("P.C of B");
		this.z = c;
	}
	public void setZ(int z)
	{
		this.z = z;
	}
	public int getZ() { 
		return this.z;
	 }
	public void show2()
	{
		System.out.println("z :"+this.z);
		//System.out.println("x :"+super.getX());
		//System.out.println("y :"+super.getY());
		super.show();
	}
	public int sum()
	{
		int res = this.z + super.getX() + super.getY();
		return res;
		//return this.z + super.getX() + super.getY();
	}
}