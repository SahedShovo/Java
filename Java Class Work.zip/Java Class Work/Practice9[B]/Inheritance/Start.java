import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		B obj1 = new B();
		obj1.show();
		System.out.println();
		obj1.show2();
		System.out.println();
		
		B obj2 = new B(1,2,3);
		obj2.show2();
		int result = obj2.sum();
		System.out.println("Result: "+result);
		System.out.println("Result: "+obj2.sum());
	}
}
