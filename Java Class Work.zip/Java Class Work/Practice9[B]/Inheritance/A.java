import java.lang.*;
public class A 
{
	private int x;
	private int y;
	public A()
	{
		System.out.println("D.C of A");
	}
	public A(int x, int y)
	{
		System.out.println("P.C of A");
		this.x = x;
		this.y = y;
	}
	public void setX(int x)
	{
		this.x = x;
	}
	public void setY(int y) { this.y = y; }
	public int getX() { return this.x; }
	public int getY() { return this.y; }
	public void show()
	{
		System.out.println("x: "+this.x);
		System.out.println("y: "+this.getY());
	}
}