import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Example obj1 = new Example(); //parent class
		System.out.println(obj1.x); //x is public, so accessible
		//System.out.println(obj1.y); //y is private, so not accessible
		System.out.println(obj1.z); //z is protected, so accessible because same package
		System.out.println();
		
		Example2 obj2 = new Example2(); //child class
		System.out.println(obj2.x); //x is public, so accessible
		//System.out.println(obj2.y); //y is private, so not accessible
		System.out.println(obj2.z); //z is protected, so accessible because same package + inheritance
	}
}