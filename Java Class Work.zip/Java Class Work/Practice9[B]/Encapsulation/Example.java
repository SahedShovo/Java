import java.lang.*;
public class Example 
{
	public int x;
	private int y;
	protected int z;
	public Example()
	{
		
	}
}