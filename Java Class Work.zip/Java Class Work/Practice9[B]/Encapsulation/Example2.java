import java.lang.*;
public class Example2 extends Example 
{
	
}