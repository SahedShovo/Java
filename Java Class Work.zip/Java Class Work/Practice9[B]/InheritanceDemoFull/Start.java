import java.lang.*;

public class Start
{
  public static void main(String[] args)
  {
     Rectangle r1 = new Rectangle();
     r1.setX(1.5);
     r1.setY(10.5);
     System.out.println("r1 x:"+r1.getX());
     System.out.println("r1 y:"+r1.getY());
     System.out.println("r1 area:"+r1.getArea());
     Rectangle r2 = new Rectangle(10.5, 5.5);
     System.out.println("r2 x:"+r2.getX());
     System.out.println("r2 y:"+r2.getY());
     System.out.println("r2 area:"+r2.getArea());
    Circle c2 = new Circle(5.5);
    System.out.println("c2 x:"+c2.getX());
    System.out.println("c2 area:"+c2.getArea());
    System.out.println();
  }
}
