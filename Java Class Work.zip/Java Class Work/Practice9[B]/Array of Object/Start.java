import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Box obj1 = new Box();
		obj1.setHeight(5);
		obj1.setLength(10);
		obj1.setWidth(15);
		System.out.println("Height is: "+obj1.getHeight());
		System.out.println();
		
		obj1.showDetails();
		System.out.println();
		
		Box obj2 = new Box(2,3,4);
		obj2.showDetails();
		System.out.println();
		
		System.out.println("Array of object");
		Box arr1[] = new Box[5];
		arr1[0] = obj1;
		arr1[1] = obj2;
		arr1[3] = obj1;
		for(int i=0; i<arr1.length; i++)
		{
			//arr1[i].showDetails();
			//System.out.println();
			if(arr1[i] != null)
			{
				System.out.println("Box "+(i+1)+" information");
				arr1[i].showDetails();
				System.out.println();
			}
			else 
			{
				System.out.println("Box "+(i+1)+" information");
				System.out.println("Nothing to show");
				System.out.println();
			}
		}
	}
}