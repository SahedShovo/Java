import java.lang.*;
public class Box 
{
	private int height;
	private int length;
	private int width;
	public Box()
	{
		System.out.println("Dafault cons!");
	}
	public Box(int height, int length, int width)
	{
		System.out.println("Para Cons!");
		this.height = height;
		this.length = length;
		this.width = width;
	}
	public void setHeight(int height)
	{
		this.height = height;
	}
	public void setLength(int length)
	{
		this.length = length;
	}
	public void setWidth(int width)
	{
		this.width = width;
	}
	public int getHeight()
	{
		return this.height;
	}
	public int getLength()
	{
		return this.length;
	}
	public int getWidth()
	{
		return this.width;
	}
	public void showDetails()
	{
		System.out.println("Height: "+this.height);
		System.out.println("Length: "+this.length);
		System.out.println("Width: "+this.width);
	}
	public int volumeCalculate()
	{
		System.out.println("Volume calculating..");
		int volume = this.height * this.length * this.width;
		return volume;
		//return this.height*this.length*this.width;
	}
}