import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Box obj1 = new Box();
		obj1.setHeight(5);
		obj1.setLength(10);
		obj1.setWidth(15);
		obj1.showDetails();
		System.out.println("Volume is:"+obj1.volumeCalculate());
	}
}

