//step 0
import java.lang.*;
import javax.swing.*;
import java.awt.*; //this package is used for font & coloring
//step 1
public class FrameSample extends JFrame 
{
	//step 2
	private JPanel panel;
	private JLabel label1, label2, label3, label4, label5, label6, label7;
	private JTextField txt1;
	private JPasswordField pf;
	private JButton bt1;
	private JRadioButton rb1, rb2;
	private ButtonGroup bg;
	private JCheckBox cb1, cb2;
	private JComboBox jb;
	private ImageIcon img;
	private Color color1, color2, color3;
	private Font f1;
	
	//step 4
	public FrameSample() 
	{
		//step 4 (a)
		super("My First GUI");
		//super.setSize(800,400); //(width,height)
		super.setBounds(600,200, 800,450); //(x,y,width, height)
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(0, 0, 186); //(R,G,B)
		
		//step 4 (b)
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(color1);
		
		//step 4 (d)
		label1 = new JLabel("Hello OOP1[B]");
		label1.setBounds(130,20,140,30);
		panel.add(label1);
		f1 = new Font("Cambria",Font.BOLD,20); //(name, style, size)
		label1.setFont(f1);
		color2 = new Color(255, 0, 0); //(R,G,B)
		label1.setForeground(color2);
		color3 = new Color(0, 0, 0); //(R,G,B)
		label1.setBackground(color3);
		label1.setOpaque(true); //used for color overlapping
		
		
		label2 = new JLabel("Your Name");
		label2.setBounds(100,70,80,60);
		panel.add(label2);
		
		txt1 = new JTextField();
		txt1.setBounds(190,90,150,20);
		panel.add(txt1);
		txt1.setBackground(Color.RED);
		
		label3 = new JLabel("Your CGPA");
		label3.setBounds(100,100,80,60);
		panel.add(label3);
		
		pf = new JPasswordField();
		pf.setBounds(190,120,150,20);
		panel.add(pf);
		pf.setBackground(Color.RED);
		pf.setEchoChar('*');
		
		label4 = new JLabel("Your Gender");
		label4.setBounds(100,130,80,60);
		panel.add(label4);
		
		rb1 = new JRadioButton("Male");
		rb1.setBounds(200,145,60,25);
		panel.add(rb1);
		rb1.setBackground(Color.GREEN);
		rb1.setForeground(Color.RED);
		
		rb2 = new JRadioButton("Female");
		rb2.setBounds(280,145,80,25);
		panel.add(rb2);

		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		
		
		label5 = new JLabel("Topic");
		label5.setBounds(100,160,80,60);
		panel.add(label5);
		
		cb1 = new JCheckBox("Inheritance");
		cb1.setBounds(200,175,150,25);
		panel.add(cb1);
		
		cb2 = new JCheckBox("GUI");
		cb2.setBounds(200,205,150,25);
		panel.add(cb2);
		cb2.setBackground(Color.RED);
		cb2.setForeground(Color.GREEN);
		
		label6 = new JLabel("Section");
		label6.setBounds(100,230,80,60);
		panel.add(label6);
		
		String arr1[] = new String[] {" ", "A", "B", "C"};
		jb = new JComboBox(arr1);
		jb.setBounds(200,250,80,20);
		panel.add(jb);
		jb.setBackground(Color.BLACK);
		jb.setForeground(Color.YELLOW);
		
		img = new ImageIcon("SectionB.jpg");
		label7 = new JLabel(img);
		label7.setBounds(400,40,350,257);
		panel.add(label7);
		
		bt1 = new JButton("Submit");
		bt1.setBounds(290,280,100,20);
		panel.add(bt1);
		bt1.setBackground(Color.GREEN);
		bt1.setForeground(Color.RED);
		
		//step 4 (f)
		super.add(panel);
	}
}