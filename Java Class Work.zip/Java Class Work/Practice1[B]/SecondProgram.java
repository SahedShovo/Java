import java.lang.*;//Importing all files in lang folder
public class SecondProgram 
{
	public static void main(String[] abc)
	{
		System.out.println("2nd Program");
		int x = 10;
		int y = 5;
		System.out.println("AIUB"); //AIUB
		System.out.println("AIUB"+x); //AIUB10
		System.out.println("AIUB"+x+y); //AIUB105
		System.out.println("AIUB"+(x+y)); //AIUB15
		System.out.println(x+y+"AIUB"); //15AIUB
		System.out.println((x+y)+"AIUB"); //15AIUB
		System.out.println(x+(y+"AIUB")); //105AIUB
	}
}