import java.lang.String; //String class importing
import java.lang.System; //System class importing
public class FirstProgram 
{
	public static void main(String[] args)
	{
		System.out.println("1st Program");
		
		String s1 = "1234";
		System.out.println("Value of String, s1: "+s1);
		
		int i1;
		i1 = Integer.parseInt(s1); //Using Wrapper class to convert from String to int
		System.out.println("Value of int, i1: "+i1);
	}
}