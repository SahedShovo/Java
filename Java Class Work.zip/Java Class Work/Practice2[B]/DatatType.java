import java.lang.*;
public class DatatType
{
	public static void main(String[] args)
	{
		System.out.println("Hello!");
		byte b1 = 127;
		System.out.println("Value of b1: "+b1);
	}
}	