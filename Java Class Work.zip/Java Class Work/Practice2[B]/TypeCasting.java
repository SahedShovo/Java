import java.lang.*;
public class TypeCasting 
{
	public static void main(String[] args)
	{
		int i1 = 20; //4 bytes capacity
		System.out.println("Value of i1: "+i1);
		long l1; //8 bytes capacity
		l1 = i1; //implicit casting
		System.out.println("Value of l1: "+l1);
		
		double d1 = 2.56; //8 bytes capacity
		System.out.println("Value of d1: "+d1);
		float f1; //4 bytes capacity
		f1 = (float)d1; //explicit casting
		System.out.println("Value of f1: "+f1);
		
		short s1 = 128; //2 bytes capacity
		System.out.println("Value of s1: "+s1);
		byte b1; //1 byte capacity
		b1 = (byte)s1; //explicit casting
		System.out.println("Value of b1: "+b1);
	}
}