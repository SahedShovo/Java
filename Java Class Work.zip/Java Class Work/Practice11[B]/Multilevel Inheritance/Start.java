import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		C obj1 = new C();
		C obj2 = new C(1,2,3);
		System.out.println();
		
		obj2.show3();
	}
}