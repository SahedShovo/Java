import java.lang.*;
public class C extends B 
{
	private int z;
	public C()
	{
		System.out.println("D.C of C");
	}
	public C(int x, int y, int z)
	{
		super(x,y);
		this.z = z;
		System.out.println("P.C of C");
	}
	public void setZ(int z) { this.z = z; }
	public int getZ() { return this.z; }
	public void show3()
	{
		super.show2();
		System.out.println("z: "+this.z);
	}
}
