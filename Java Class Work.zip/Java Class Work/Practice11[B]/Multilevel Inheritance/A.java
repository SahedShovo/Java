import java.lang.*;
public class A 
{
	private int x;
	public A()
	{
		System.out.println("D.C of A");
	}
	public A(int x)
	{
		System.out.println("P.C of A");
		this.x = x;
	}
	public void setX(int x) { this.x = x; }
	public int getX() { return this.x; }
	public void show1()
	{
		System.out.println("x: "+this.x);
	}
}