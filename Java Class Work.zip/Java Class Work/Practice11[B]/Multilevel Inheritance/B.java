import java.lang.*;
public class B extends A 
{
	private int y;
	public B()
	{
		System.out.println("D.C of B");
	}
	public B(int x, int y)
	{
		super(x);
		System.out.println("P.C of B");
		this.y = y;
	}
	public void setY(int y) { this.y = y; }
	public int getY() { return this.y; }
	public void show2()
	{
		super.show1();
		System.out.println("y: "+this.y);
	}
}