import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Employee e1 = new Employee("Mr X", 20, 25000);
		Employee e2 = new Employee("Mr Y", 25, 30000);
		Employee e3 = new Employee("Mr Z", 30, 35000);
		Employee e4 = new Employee("Mr XX", 35, 40000);
		Employee e5 = new Employee();
		e5.setEmpName("Mr YY");
		e5.setEmpAge(40);
		e5.setEmpSal(45000);
		System.out.println("Employee e5 salary: "+e5.getEmpSal());
		System.out.println();
		
		Bank bank = new Bank("AB Bank", "Gulshan");
		bank.AddEmployee(e1); //index 0 = e1
		bank.AddEmployee(e2); //index 1 = e2 
		bank.AddEmployee(e3); //index 2 = e3
		bank.AddEmployee(e4); //index 3 = e4
		bank.AddEmployee(e5); //index 4 = e5
		System.out.println();
		bank.showEmployees();
		bank.deleteEmployee(e5); //index 4 = null
		bank.showEmployees();
	}
}