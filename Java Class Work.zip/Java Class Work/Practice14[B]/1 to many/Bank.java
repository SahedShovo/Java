//Bank has many Employees (1 to many Association)
import java.lang.*;
public class Bank 
{
	private String bankName;
	private String bankLoc;
	//Bank will hire 100 Employees but not using parameterized cons
	private Employee emp[] = new Employee[100]; //'emp' is the representer of Employee class 
												// which is not an Array of Employee type (non premitive)
	public Bank()
	{
		
	}
	public Bank(String bankName, String bankLoc)
	{
		this.bankName = bankName;
		this.bankLoc = bankLoc;
	}
	public void setBankName(String bankName)
	{
		this.bankName = bankName;
	}
	public void setBankLoc(String bankLoc)
	{
		this.bankLoc = bankLoc;
	}
	public String getBankName() { return this.bankName; }
	public String getBankLoc() { return this.bankLoc; }
	public void AddEmployee(Employee e)
	{
		boolean flag = false; //Initially no employee assign
		for(int i=0; i<emp.length; i++) //length = 100
		{
			if(emp[i] == null)
			{
				emp[i] = e;
				flag = true;
				break;
			}
		}
		if(flag == true)
		{
			System.out.println("Employee added!");
		}
		else 
		{
			System.out.println("Employee cann't add");
		}
	}
	public void deleteEmployee(Employee e)
	{
		int flag = 0;
		for (int i=0; i<emp.length; i++)
		{
			if(emp[i] == e)
			{
				emp[i] = null;
				flag = 1;
				break;
			}
		}
		if(flag == 1)
		{
			System.out.println("Employee deleted!");
		}
		else 
		{
			System.out.println("Employee not found!");
		}
	}
	public void showEmployees()
	{
		for(int i=0; i<emp.length; i++)
		{
			if(emp[i] == null)
			{
				System.out.println("Index: "+i);
				System.out.println("Bank Name: "+this.bankName);
				System.out.println("Bank Location: "+this.bankLoc);
				System.out.println("No employee found!"); 
				System.out.println();
			}
			else
			{
				System.out.println("Index: "+i);
				System.out.println("Bank Name: "+this.bankName);
				System.out.println("Bank Location: "+this.bankLoc);
				emp[i].showEmpInfo();
			}
		}
	}
}
