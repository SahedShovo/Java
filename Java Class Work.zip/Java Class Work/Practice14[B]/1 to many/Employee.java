import java.lang.*;
public class Employee 
{
	private String empName;
	private int empAge;
	private double empSal;
	public Employee()
	{
		
	}
	public Employee(String empName, int empAge, double empSal)
	{
		this.empName = empName;
		this.empAge = empAge;
		this.empSal = empSal;
	}
	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public void setEmpAge(int empAge) 
	{
		this.empAge = empAge;
	}
	public void setEmpSal(double empSal)
	{
		this.empSal = empSal;
	}
	public String getEmpName() { return this.empName; }
	public int getEmpAge() { return this.empAge; }
	public double getEmpSal() { return this.empSal; }
	public void showEmpInfo()
	{
		System.out.println("Emp Name: "+this.empName);
		System.out.println("Emp Age: "+this.empAge);
		System.out.println("Emp Salary: "+this.empSal);
		System.out.println();
	}
}