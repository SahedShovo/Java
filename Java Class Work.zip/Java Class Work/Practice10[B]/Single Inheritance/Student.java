import java.lang.*;
public class Student extends Person
{
	private String id;
	private double cgpa;
	public Student()
	{
		//super();
		System.out.println("D.C of Student");
	}
	public Student(String name, int age, String id, double cgpa)
	{
		super(name, age);
		this.id = id;
		this.cgpa = cgpa;
		System.out.println("P.C of Student");
	}
	public void setId(String id) { this.id = id; }
	public void setCgpa(double cgpa) { this.cgpa = cgpa; }
	public String getId() { return this.id; }
	public double getCgpa() { return this.cgpa; }
	public void showDetails()
	{
		super.show();
		System.out.println("ID: "+this.id);
		System.out.println("Cgpa: "+this.cgpa);
	}
	public String getNameAge()
	{
		String name = super.getName();
		int age = super.getAge();
		String concat = name+age; //String concat
		return concat;
	}
	
}