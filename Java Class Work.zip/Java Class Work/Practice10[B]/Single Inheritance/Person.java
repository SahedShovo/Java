import java.lang.*;
public class Person
{
	private String name;
	private int age;
	public Person()
	{
		System.out.println("D.C of Person");
	}
	public Person(String name, int age)
	{
		System.out.println("P.C of Person");
		this.name = name;
		this.age = age;
	}
	public void setName(String name) { this.name = name; }
	public void setAge(int age) { this.age = age; }
	public String getName() { return this.name; }
	public int getAge() { return this.age; }
	public void show()
	{
		System.out.println("Name: "+this.name); //concept of encapsulation
		System.out.println("Age: "+this.getAge());
	}
	public static void main(String[] args)
	{
		Student obj1 = new Student("Rakib", 21, "12-23453-3", 3.5);
		obj1.showDetails();
		System.out.println();
		
		System.out.println(obj1.getNameAge());
	}
}