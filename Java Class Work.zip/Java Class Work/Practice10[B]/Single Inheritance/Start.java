import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Student obj1 = new Student("Rakib", 21, "12-23453-3", 3.5);
		obj1.showDetails();
		System.out.println();
		
		System.out.println(obj1.getNameAge());
	}
}