public class Start {
    public static void main(String[] args) {
        Book book1 = new Book("23-52494-2", "Java", "sahed", 42.50, 100);
        Book book2 = new Book("23-52493-2", "Data Structures", "fahad", 32.50, 90);
        Book book3 = new Book("23-52492-2", "C++", "Nahid", 42.99, 70);
        Book book4 = new Book("23-52491-2", "Algorithum", "Saimoon", 3.60, 60);
        Book book5 = new Book("23-52493-2", "Design", "Ahmed", 29.9, 55);

        Book bookArray[] = new Book[5];
        bookArray[0]=book1;
        bookArray[1]=book2;
        bookArray[2]=book3;
        bookArray[3]=book4;
        bookArray[4]=book5;

        for (int i = 0; i < bookArray.length; i++) {
            if(bookArray[i] !=null){
                System.out.println("book"+(i+1)+"info:");
                bookArray[i].showDetails();
                System.out.println();
            }
            else{
                System.out.print("book"+(i+1)+"info:");
                System.out.println("Nothing To show");
                System.out.println();

            }
           
    }
}
    
}
