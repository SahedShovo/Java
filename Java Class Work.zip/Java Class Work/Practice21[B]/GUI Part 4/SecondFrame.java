//step 0
import java.lang.*;
import javax.swing.*;
import java.awt.*; //this package is used for font & coloring
import java.awt.event.*; //used for interface
//step 1
public class SecondFrame extends JFrame implements ActionListener
{
	//step 2
	private JPanel panel;
	private Color color1;
	private JButton bt4;
	private JLabel label1, label2, label3, label4, label5;
	
	public SecondFrame()
	{
		//step 4 (a)
		super("My Second GUI");
		//super.setSize(800,400); //(width,height)
		super.setBounds(600,200, 800,500); //(x,y,width, height)
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(100, 199, 186); //(R,G,B)
		
		//step 4 (b)
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(color1);
		
		bt4 = new JButton("Back");
		bt4.setBounds(290,370,100,20);
		panel.add(bt4);
		bt4.setBackground(Color.GREEN);
		bt4.setForeground(Color.RED);
		bt4.addActionListener(this);
		
		//step 4 (f)
		super.add(panel);
	}
	public SecondFrame(String s1, String s2, String s3, String s4, String s5)
	{
		//step 4 (a)
		super("My Second GUI");
		//super.setSize(800,400); //(width,height)
		super.setBounds(600,200, 800,500); //(x,y,width, height)
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(100, 199, 186); //(R,G,B)
		
		//step 4 (b)
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(color1);
		
		bt4 = new JButton("Back");
		bt4.setBounds(290,370,100,20);
		panel.add(bt4);
		bt4.setBackground(Color.GREEN);
		bt4.setForeground(Color.RED);
		bt4.addActionListener(this);
		
		label1 = new JLabel("Your Name: "+s1);
		label1.setBounds(100,70,200,60);
		panel.add(label1);
		
		label2 = new JLabel("Your CGPA: "+s2);
		label2.setBounds(100,100,200,60);
		panel.add(label2);
		
		label3 = new JLabel("Gender: "+s3);
		label3.setBounds(100,130,200,60);
		panel.add(label3);
		
		label4 = new JLabel("Topic: "+s4);
		label4.setBounds(100,160,1200,60);
		panel.add(label4);
		
		label5 = new JLabel("Section: "+s5);
		label5.setBounds(100,190,200,60);
		panel.add(label5);
		
		//step 4 (f)
		super.add(panel);
	}
	//ActionListener interface
	//There are 1 abstract method in ActionListener interface
	//So, we need to override them in this class
	public void actionPerformed(ActionEvent me) 
	{ 
		if(me.getSource() == bt4) //if bt4 (Back) button clicked
		{
			FrameSample obj1 = new FrameSample();
			obj1.setVisible(true);
			this.setVisible(false);
		}
	}
}