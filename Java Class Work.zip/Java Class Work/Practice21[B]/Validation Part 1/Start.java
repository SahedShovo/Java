import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Newframe obj1=new Newframe();
		//Registration obj1 = new Registration();
		//Login obj1 = new Login("A","1");
		obj1.setVisible(true);
	}
}