import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Registration extends JFrame implements MouseListener, ActionListener
{
	JPanel panel;
	JLabel userlable,passlable;
	JTextField tfield;
	JPasswordField pfield;
	JButton signbtn,exitbtn;
	Color mycolor, mycolor1;
	Font myfont;
	
	
	public Registration ()
	{
		super("Registration");
		this.setBounds(280,115,800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		userlable = new JLabel("user");
		userlable.setBounds(150,115,80,30);
		userlable.setBackground(Color.RED);
		userlable.setOpaque(true);
		userlable.setForeground(Color.WHITE);
		userlable.setFont(myfont);
		panel.add(userlable);
		
		
	    tfield = new JTextField();
		tfield.setBounds(230,115,100,30);
		panel.add(tfield);
		
		passlable = new JLabel("Password:");
		passlable.setBounds(150,150,80,30);
		passlable.setBackground(Color.RED);
		passlable.setOpaque(true);
		panel.add(passlable);
		
		pfield = new JPasswordField();
		pfield.setBounds(230,150,100,30);
		panel.add(pfield);
		
		signbtn= new JButton("Signup");
		signbtn.setBounds(180,200,80,30);
		signbtn.setBackground(Color.RED);
		panel.add(signbtn);
		signbtn.addActionListener(this);
		
		exitbtn = new JButton("Exit");
		exitbtn.setBounds(280,200,80,30);
		exitbtn.setBackground(Color.ORANGE);
		panel.add(exitbtn);
		exitbtn.addActionListener(this);
		
		this.add(panel);
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource() == signbtn) //Signup clicked
		{
			String s1, s2;
			s1 = tfield.getText(); //user name
			s2 = pfield.getText(); //password
			if(s1.isEmpty() || s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this, "Please fill-up all the information"); 
			}
			else 
			{
				Account acc = new Account(s1, s2);
				acc.addAccount();
				JOptionPane.showMessageDialog(this, "Registration Successful");
				tfield.setText("");
				pfield.setText("");
				
				Newframe obj1 = new Newframe();
				obj1.setVisible(true);
				this.setVisible(false);
			}
		}
		else if(ae.getSource() == exitbtn) //Exit clicked 
		{
			System.exit(0);
		}
	}
}