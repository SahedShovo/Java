import java.util.*; //for Scanner class
import java.lang.*; //for String class
public class ScannerExample 
{
	public static void main(String[] args)
	{
		//You have to take all String type input first if you use one object
		//nextLine() => return entire String 
		//next() => return only the first word of the String
		Scanner obj1 = new Scanner(System.in);
		System.out.print("Enter your name: ");
		String s1 = obj1.nextLine();
		System.out.print("Enter your ID: ");
		String s2 = obj1.nextLine();
		System.out.print("Enter your age: ");
		int i1 = obj1.nextInt();
		
		Scanner obj2 = new Scanner(System.in);
		System.out.print("Enter your nationality: ");
		String s3 = obj2.nextLine();
		
		System.out.println("Name: "+s1);
		System.out.println("ID: "+s2);
		System.out.println("Age: "+i1);
		System.out.println("Nationality: "+s3);
		System.out.println();
		
		System.out.print("Enter a String: ");
		String s4 = obj2.next();
		System.out.println(s4);
	}
}