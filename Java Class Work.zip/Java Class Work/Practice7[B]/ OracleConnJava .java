import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class OracleConnJava {
    public static void main(String[] args) {
        try {
            // Load Oracle JDBC Driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establish connection to the database
            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "aysten", "browny");

            // Create a statement object to send SQL queries
            Statement stmt = con.createStatement();

            // Execute the SQL query and retrieve results
            ResultSet rs = stmt.executeQuery("SELECT * FROM Receptionist");

            // Iterate through the result set and print each record
            while (rs.next()) {
                // Assuming columns are: ID (int), Name (String), Phone (long)
                System.out.println(rs.getInt(1) + " " +
                                   rs.getString(2) + " " +
                                   rs.getLong(3));
            }

            // Close the connection
            con.close();
        } catch (Exception e) {
            // Print the exception if any occurs
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

