//step 6
import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		FrameSample.frame=new FrameSample();
		frame.setvisible(true);
		
	}
}