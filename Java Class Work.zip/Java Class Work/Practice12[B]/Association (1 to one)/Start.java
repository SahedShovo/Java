import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Account ac1 = new Account();
		ac1.setAccNo(1);
		ac1.setAccName("Mr X");
		ac1.setAccBalance(500.00);
		ac1.show();
		
		Account ac2 = new Account(2, "Mr Y", 1000.00);
		ac2.show();	
		
		Customer c1 = new Customer();
		c1.setPhoneNum("01321");
		c1.setAcc(ac1); //1 to 1 association
		c1.showDetails();
		
		Customer c2 = new Customer("01332", ac2);
		c2.showDetails();
	}
}