//Customer has an Account
import java.lang.*;
public class Customer 
{
	private String phoneNum;
	private Account acc; //here, 'acc' is the representer of Account class
	                     // 'acc' is also an instance variable which is non-primitive datatype
	public Customer()
	{
		
	}
	public Customer(String phoneNum, Account acc)
	{
		this.phoneNum = phoneNum;
		this.acc = acc;
	}
	public void setPhoneNum(String phoneNum)
	{
		this.phoneNum = phoneNum;
	}
	public void setAcc(Account acc)
	{
		this.acc = acc;
	}
	public String getPhoneNum() { 
		return this.phoneNum; 
	}
	public Account getAcc() { 
		return this.acc; 
	}
	public void showDetails()
	{
		System.out.println("Phone Number: "+this.phoneNum);
		acc.show();
	}
}