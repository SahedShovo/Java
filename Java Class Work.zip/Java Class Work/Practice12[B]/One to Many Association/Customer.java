//Customer has many Accounts ( 1 to many association)
import java.lang.*;
public class Customer 
{
	private String phnNum;
	private Account acc[]; //here, 'acc' is the representer of Account class 
	                       // which is an array now
	public Customer()
	{
		
	}
	public Customer(String phnNum, int size) //here size means how many Accounts you want to open?
	{
		this.phnNum = phnNum;
		this.acc = new Account[size]; //Array 2nd Approach
	}
	public void setPhnNum(String phnNum)
	{
		this.phnNum = phnNum;
	}
	public String getPhnNum() { return this.phnNum; }
	//public void setAccount(Account ac)
	//public void deleteAccount(Account ac)
	//public void showAccounts()
	public void setAccount(Account ac)
	{
		boolean flag = false; //initially no account add
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] == null) 
			{
				acc[i] = ac;
				flag = true;
				break;
			}
		}
		if(flag == true)
		{
			System.out.println("Account added!");
		}
		else 
		{
			System.out.println("Can't add");
		}
	}
	public void deleteAccount(Account ac)
	{
		int flag = 0; //Initially not delete any account
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] == ac)
			{
				acc[i] = null; //Account delete
				flag = 1;
				break;
			}
		}
		if(flag == 1)
		{
			System.out.println("Account deleted!");
		}
		else 
		{
			System.out.println("Account not found!");
		}
	}
	public void showAccounts()
	{
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] == null)
			{
				System.out.println("No Accounts");
			}
			else 
			{
				System.out.println("Index: "+i);
				acc[i].show();
			}
		}
	}
}