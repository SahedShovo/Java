import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Account ac1 = new Account(1, "Mr X", 500.00);
		Account ac2 = new Account(2, "Mr Y", 1000.00);
		Account ac3 = new Account(3, "Mr Z", 1500.00);
		
		Customer c1 = new Customer("0124", 5); //size = 5 means Customer wants to create 5 Accounts
		c1.showAccounts(); //Nothing to show 
		System.out.println();
		c1.setAccount(ac1); //index 0 = ac1
		c1.setAccount(ac2); //index 1 = ac2
		c1.setAccount(ac3); //index 2 = ac3
		System.out.println();
		c1.showAccounts();
		c1.deleteAccount(ac3); //index 2 = null
		c1.deleteAccount(ac3); //Can't find
		c1.deleteAccount(ac1); //index 0 = null
		System.out.println();
		System.out.println();
		c1.showAccounts();
	}
}