import java.lang.*;
public class Account 
{
	private int accNo;
	private String accName;
	private double accBalance;
	public Account()
	{
		
	}
	public Account(int accNo, String accName, double accBalance)
	{
		this.accNo = accNo;
		this.accName = accName;
		this.accBalance = accBalance;
	}
	public void setAccNo(int accNo) 
	{
		this.accNo = accNo; 
	}
	public void setAccName(String accName) { this.accName = accName; }
	public void setAccBalance(double accBalance) { this.accBalance = accBalance; }
	public int getAccno() { return this.accNo; }
	public String getAccName() { return this.accName; }
	public double getAccBalance() { return this.accBalance; }
	public void show()
	{
		System.out.println("Account Number: "+this.accNo);
		System.out.println("Account Name: "+this.accName);
		System.out.println("Account Balance: "+this.accBalance);
		System.out.println();
	}
}