public interface OnetoManyOperations 
{
	//it is an interface now
	//so, interface will store only abstact methods
	//by default, all abstact methods will be there
	//for 1 to many accociatin, we always implement 3 new methods named as
	// add, remove, show
	//now, we will abstact those three methods
	public abstract void addAccount(Account ac);
	public abstract void removeAccount(Account ac);
	public abstract void showAllAccounts();
}