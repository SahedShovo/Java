import java.lang.*;
public class SavingsAccount extends Account 
{
	private double rate;
	public SavingsAccount() { }
	public SavingsAccount(String accNo, double accBal, double rate)
	{
		super(accNo, accBal);
		this.rate = rate;
	}
	public void setRate(double rate) 
	{
		this.rate = rate;
	}
	public double getRate() { return this.rate; }
}