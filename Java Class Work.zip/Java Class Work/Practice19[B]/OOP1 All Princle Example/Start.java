import java.lang.*;
public class Start 
{
	public static void main(String[] args) 
	{
		//FixedAccount f1 = new FixedAccount("AC1", 1000, 1);
		Account acc1 = new FixedAccount("AC1", 1000, 1); //by using obj ref
		Account acc2 = new SavingsAccount("AC2", 500, 0.2); //by using obj ref
		
		//FixedAccount obj1  = new Account("AC3", 2000); //gives error
		Customer c1 = new Customer(1, "Mr X", 5);
		//Customer c2 = new Account("AC4", 3000); //gives error
		c1.showAllAccounts();
		c1.addAccount(acc1); //index 0 = acc1
		c1.addAccount(acc2); //index 1 = acc2
		c1.showAllAccounts();
		c1.removeAccount(acc1); //index 0 = null
		c1.removeAccount(acc1);
		c1.showAllAccounts();
	}
}