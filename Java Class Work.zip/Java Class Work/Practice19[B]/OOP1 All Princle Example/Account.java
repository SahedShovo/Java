import java.lang.*;
public abstract class Account //Account is parent & abstract class
{
	private String accNo;
	private double accBal;
	public Account() { }
	public Account(String accNo, double accBal)
	{
		this.accNo = accNo;
		this.accBal = accBal;
	}
	public void setAccNo(String accNo)
	{
		this.accNo = accNo;
	}
	public void setAccBal(double accBal)
	{
		this.accBal = accBal;
	}
	public String getAccNo() { return this.accNo; }
	public double getAccBal() { return this.accBal; }
}