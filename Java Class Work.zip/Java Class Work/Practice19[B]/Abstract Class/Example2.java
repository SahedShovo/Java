import java.lang.*;
public class Example2 extends Example 
{
	public void show2()
	{
		System.out.println("Child Show");
	}
}