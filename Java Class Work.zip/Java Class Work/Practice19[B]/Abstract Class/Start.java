import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		//Example obj1 = new Example(); //gives error, becasue Example is Abstact class
		Example obj2 = new Example2(); //by using obj reference
		obj2.show();
	}
}