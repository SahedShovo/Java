import java.lang.*;
public abstract class Example 
{
	public void show()
	{
		System.out.println("Parent Showing!");
	}
}