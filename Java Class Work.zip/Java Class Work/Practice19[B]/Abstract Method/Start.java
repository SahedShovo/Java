import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		ABC obj1 = new XYZ(); //using obj refrecence; because ABC is Abstact class
		obj1.show();
	}
}