import java.lang.*;
public class XYZ extends ABC
{
	public void show() //abstract method from parent class + method overiding
	{
		System.out.println("ABC Showing from XYZ!");
	}
}