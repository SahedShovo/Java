import java.lang.*;
public abstract class ABC 
{
	public abstract void show(); //abstract method
	//{
	//	System.out.println("ABC Showing!");
	//}
}