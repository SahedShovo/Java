public class MySecondCharlie extends MyCharlie
{
	//public abstract void print();
	public void print()
	{
		System.out.println("Printing!");
	}
}