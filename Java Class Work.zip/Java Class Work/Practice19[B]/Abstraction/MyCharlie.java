public abstract class MyCharlie extends Charlie
{
	//public abstract void show();
	//public abstract void print();
	public void show()
	{
		System.out.println("Showing!");
	}
	//missing print() method
}