import java.lang.*;
public abstract class Charlie 
{
	public abstract void show();
	public abstract void print();
}