public class Start 
{
	public static void main(String[] args)
	{
		MySecondCharlie obj1 = new MySecondCharlie();
		obj1.print();
		obj1.show();
		System.out.println();
		
		Charlie obj2 = new MySecondCharlie();
		obj2.print();
		obj2.show();
	}
}