import java.lang.*;
public class ClassExample 
{
	public int x; //instance attribute
	public int y = 10; //instance attribute
	
	public ClassExample()//default cons
	{
		System.out.println("Default Cons");
		//this.x = 0; //assigning default value of x
		//this.y = 0; //assigning default value of y
	}
	ClassExample(int x, int y) //parameterized cons
	{
		System.out.println("Para Cons");
		this.x = x; //assigning the value of the parameter x
		this.y = y; //assigning the value of the parameter y
	}
	public static void main(String[] args)
	{
		ClassExample obj1 = new ClassExample();
		System.out.println("Defaule value of x: "+obj1.x);
		System.out.println("Value of y: "+obj1.y);
		obj1.x = 20;
		System.out.println("Updated value of x: "+obj1.x);
	}	
}