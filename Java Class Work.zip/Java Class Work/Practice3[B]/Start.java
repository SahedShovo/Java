import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		ClassExample2 obj1 = new ClassExample2();
		//System.out.println(obj1.x); //gives error because x is private in ClassExample2
		System.out.println(obj1.getX());
		obj1.setX(10);
		System.out.println(obj1.getX());
		System.out.println();
		
		ClassExample obj2 = new ClassExample();
		System.out.println(obj2.x);
	}
}