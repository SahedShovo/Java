import java.lang.*;
public class ClassExample2 
{
	private int x;
	private int y;
	ClassExample2()
	{
		System.out.println("Default Cons Called!");
	}
	public ClassExample2(int x, int y)
	{
		System.out.println("Para Cons Called!");
		this.x = x;
		this.y = y;
	}
	//set methods
	public void setX(int x)
	{
		System.out.println("Value of X setting!");
		this.x = x;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	//get methos
	public int getX()
	{
		return this.x;
	}
	public int getY()
	{
		return this.y;
	}
}