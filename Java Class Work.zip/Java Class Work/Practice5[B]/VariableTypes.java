import java.lang.*;
public class VariableTypes 
{
	public static int a; //class or static variable
	private int b; //instance variable
	static //static block 1, used for initialize static variable
	{
		System.out.println("Static block 1 called!");
		a = 100;
	}
	static //static block 2, used for initialize static variable
	{
		System.out.println("Static block 2 called!");
		a = 200;
	}
	public VariableTypes() //default cons
	{
		System.out.println("Default cons!");
	}
	static //static block 3, used for initialize static variable
	{
		System.out.println("Static block 3 called!");
		a = 300;
	}
	public static void main(String[] args)
	{
		System.out.println(VariableTypes.a); //400
		VariableTypes obj1 = new VariableTypes();
		System.out.println(obj1.a); //400
		VariableTypes.a = 600;
		System.out.println(obj1.a); //600
		obj1.a = 800;
		System.out.println(VariableTypes.a); //800
		
		System.out.println();
		int i; //local variable
		for(i=0;i<5;i++)
		{
			System.out.println("Hello Java!");
		}
		if(5%2 != 0)
		{
			String s1; //local variable
			s1 = "Can't devide!"; 
			System.out.println(s1);
		}
	}
	static //static block 4, used for initialize static variable
	{
		System.out.println("Static block 4 called!");
		a = 400;
	}
}