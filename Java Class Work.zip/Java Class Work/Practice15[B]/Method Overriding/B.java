import java.lang.*;
public class B extends A 
{
	public void show(int x)
	{
		System.out.println("Class B");
		super.show(x);
	}
}