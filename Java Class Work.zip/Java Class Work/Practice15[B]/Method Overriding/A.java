import java.lang.*;
public class A 
{
	public void show(int x)
	{
		System.out.println("Class A");
		System.out.println(x);
	}
}