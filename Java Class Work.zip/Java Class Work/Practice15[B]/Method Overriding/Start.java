import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		B obj1 = new B();
		obj1.show(10);
	}
}