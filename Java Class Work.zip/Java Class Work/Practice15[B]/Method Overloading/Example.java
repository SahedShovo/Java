import java.lang.*;
public class Example 
{
	public void sum(int x, int y)
	{
		System.out.println(x+y);
	}
	public void sum(int x, int y, int z)
	{
		System.out.println(x+y+z);
	}
	public double sum(double x, double y)
	{
		return x+y;
	}
}