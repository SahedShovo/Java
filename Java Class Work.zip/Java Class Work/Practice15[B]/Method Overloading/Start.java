import java.lang.*;
public class Start 
{
	public static void main(String[] args)
	{
		Example obj1 = new Example();
		obj1.sum(10,20);
		obj1.sum(10,20,30);
		System.out.println(obj1.sum(4.5, 5.5));
	}
}