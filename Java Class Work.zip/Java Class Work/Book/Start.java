import javax.sound.sampled.SourceDataLine;
import java.lang.*;
public class Start {
    public static void main(String[] args) {
        Book obj1=new Book();
        System.out.println("USing Set Get MAthood:");
        obj1.setIsbn("59114");
        obj1.setBookTitle("Java");
        obj1.setAuthorName("Sahed");
        obj1.setPrice(500);
        obj1.setAvailableQuantity(600);
        obj1.showDetails();
        obj1.sellQuantity(20);
        obj1.addQuantity(50);

        System.out.println("ISBN: " + obj1.getIsbn());
        System.out.println("Title: " +obj1.getBookTitle());
        System.out.println("Author: "  +obj1.getAuthorName());
        System.out.println("Price:"  +obj1.getPrice());
        System.out.println("Available Quantity: " +obj1.getAvailableQuantity());

        System.out.println(" ");
        Book obj2=new Book("235249","Goodday","Robindronath",270,525);
        obj2.showDetails();
    }
    }
    

