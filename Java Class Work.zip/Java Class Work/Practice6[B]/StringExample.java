import java.lang.*;
public class StringExample 
{
	public static void main(String[] args)
	{
		//3 ways to declare Strings
		//1st way
		String obj1 = new String();
		System.out.println("Default value: "+obj1); //""
		String obj2 = new String("AIUB");
		System.out.println(obj2); //AIUB
		
		//2nd way
		String s1 = "Java[B]";
		System.out.println(s1); //Java[B]
		
		//3rd way
		int age = 20;
		String s2 = "I am "+age+" years old";
		System.out.println(s2); //I am 20 years old
		
		//calling String methods
		System.out.println(s1.length()); //7
		System.out.println(s2.length()); //17
		System.out.println(s2.charAt(2)); //a
		System.out.println(s2.charAt(4)); //""
		
		String s3 = "America";
		String s4 = "American";
		System.out.println(s3.equals(s4)); //true
		System.out.println(s3.compareTo(s4)); //0 Asci value ( - )Hobe
		String s5 = "Americann";
		System.out.println(s4.compareTo(s5)); //-2 Asci value ( - )Hobe 
		System.out.println(s5.compareTo(s4)); //2
		//s2 = I am 20 years old
		System.out.println(s2.indexOf('I')); //2
		System.out.println(s2.indexOf("20")); //5
		System.out.println(s2.indexOf("I am 20 years old")); //0
		System.out.println(s2.substring(2,4)); //am
		System.out.println(s2.substring(2,9)); //am 20 y
		System.out.println(s4.toUpperCase()); //AMERICA
		System.out.println(s4.toLowerCase()); //america
		
		String s6 = "Mr X";
		String s7 = "Mr Y";
		System.out.println(s6.equals(s7)); //false
		System.out.println(s6==s7); //false
		
		String obj3 = new String("Mr Z");
		String obj4 = new String("Mr Z");
		System.out.println(obj3.equals(obj4)); //true
		System.out.println(obj3==obj4); //false
		System.out.println(obj3!=obj4); //true
		System.out.println(s6.isEmpty());//false
		System.out.println(s6.concat(s7)); //Mr XMr Y

	}
}