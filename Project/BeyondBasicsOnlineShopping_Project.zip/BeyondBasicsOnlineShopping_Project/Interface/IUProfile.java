package Interface;
import classes.*;

import java.awt.event.ActionEvent;

public interface IUProfile {
    void actionPerformed(ActionEvent e);
}
