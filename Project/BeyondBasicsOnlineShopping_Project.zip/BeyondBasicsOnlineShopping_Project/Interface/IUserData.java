package Interface;
import classes.*;

import java.awt.event.ActionEvent;

public interface IUserData {
    void actionPerformed(ActionEvent e);
}
