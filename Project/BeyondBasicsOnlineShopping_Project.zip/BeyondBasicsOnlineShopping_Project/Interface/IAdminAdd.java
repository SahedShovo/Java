package Interface;
import classes.*;

import java.awt.event.ActionEvent;

public interface IAdminAdd {
    void actionPerformed(ActionEvent e);
}
