package Interface;

import java.awt.event.ActionEvent;

public interface ICustomerSignIn {
    void actionPerformed(ActionEvent e);
}
