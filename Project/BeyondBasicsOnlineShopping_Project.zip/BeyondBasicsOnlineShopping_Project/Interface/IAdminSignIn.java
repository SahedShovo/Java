package Interface;

import java.awt.event.ActionEvent;

public interface IAdminSignIn {
    void actionPerformed(ActionEvent e);
}
