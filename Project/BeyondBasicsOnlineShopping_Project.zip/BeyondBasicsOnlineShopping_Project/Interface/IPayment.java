package Interface;

import java.awt.event.ActionEvent;

public interface IPayment {
    void actionPerformed(ActionEvent e);
}
