package Interface;
import classes.*;

import java.awt.event.ActionEvent;

public interface ICustomerSignUp {
    void actionPerformed(ActionEvent e);
}
