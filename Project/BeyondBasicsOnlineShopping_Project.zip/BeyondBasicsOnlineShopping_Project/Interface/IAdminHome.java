package Interface;
import classes.*;

import java.awt.event.ActionEvent;

public interface IAdminHome {
    void actionPerformed(ActionEvent e);
}
